Config = {
    -- Debug Setting
    Debug = false, -- Set to false in production

    -- Manual Dispatch Settings
    BlipDuration = 300000, -- 5 minutes
    EmergencyJobs = {
        ['police'] = true,
        ['ambulance'] = true
    },
    BlipSettings = {
        emergency = {
            sprite = 161,
            scale = 1.2,
            color = 1,
            name = "911 Call"
        },
        nonEmergency = {
            sprite = 161,
            scale = 1.2,
            color = 3,
            name = "311 Call"
        },
        police = {
            sprite = 1,
            scale = 0.8,
            color = 3, -- Blue
            name = "Police Officer"
        },
        ambulance = {
            sprite = 1,
            scale = 0.8,
            color = 23, -- Pink
            name = "EMS"
        }
    },
    
    -- Callsign Settings
    CallsignPatterns = {
        police = "^%d+$", -- Only numbers
        ambulance = "^[A-Z]%-%d%d$" -- Letter-hyphen-2digits
    },
    MaxCallsignLength = {
        police = 4, -- Maximum 4 digits for police
        ambulance = 4  -- A-XX format is always 4 characters
    },
    
    -- Auto Dispatch Settings
    AutoDispatch = {
            ['shooting'] = {
                code = '10-71',
                title = 'Shots Fired',
                description = 'Reports of gunfire in the area',
                blipSprite = 110,
                blipColor = 1,
                blipScale = 1.2,
                blipTimeout = 120000,
                category = 'shooting',
                jobs = {'police', 'sheriff'}, -- Added required jobs array
                cooldown = 30000,            -- Added cooldown time
                radius = 100.0,             -- Added detection radius
                notifyType = 'error',       -- Added notification type
                icon = 'gun'                -- Added icon
            },
            ['pursuit'] = {
                code = '10-31',
                title = 'Active Pursuit',
                description = 'Suspect fleeing from scene',
                blipSprite = 225,
                blipColor = 3,
                blipScale = 1.0,
                blipTimeout = 90000,
                category = 'pursuit',
                jobs = {'police', 'sheriff'},
                cooldown = 45000,
                radius = 50.0,
                notifyType = 'inform',
                icon = 'person-running'
            },
            ['drug-selling'] = {
                code = '10-31B',
                title = 'Drug Activity',
                description = 'Suspicious transaction observed',
                blipSprite = 51,
                blipColor = 2,
                blipScale = 1.0,
                blipTimeout = 60000,
                category = 'drug-selling',
                jobs = {'police', 'sheriff'},
                cooldown = 60000,
                radius = 75.0,
                notifyType = 'warning',
                icon = 'cannabis'
            }
    },

    -- Notification Settings
    ChatColors = {
        dispatch = {r = 48, g = 145, b = 255}, -- Blue for dispatch
        emergency = {r = 255, g = 48, b = 48}, -- Red for emergency
        nonEmergency = {r = 240, g = 200, b = 80} -- Yellow for non-emergency
    }
}