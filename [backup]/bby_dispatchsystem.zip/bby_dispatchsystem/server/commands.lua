ESX = exports["es_extended"]:getSharedObject()
local activeCallsigns = {}

-- Emergency call commands
for _, cmd in ipairs({'911', '911a', '311', '311a', '13A'}) do
    RegisterCommand(cmd, function(source, args, rawCommand)
        local xPlayer = ESX.GetPlayerFromId(source)
        if not xPlayer then return end

        -- 13A Command (Officer Down) - Police only
        if cmd == '13A' then
            if xPlayer.job.name ~= 'police' then
                TriggerClientEvent('esx:showNotification', source, "You are not authorized to use this command.")
                return
            end

            -- Play gunshot sound for nearby players
            TriggerClientEvent('emergency:playGunshotSound', source)

            -- Notify all emergency services of 'Officer Down'
            local dispatchData = {
                type = "OFFICER DOWN",
                caller = { name = "Officer", phone = "UNKNOWN" },
                message = "Officer down - Immediate assistance required!",
                coords = GetEntityCoords(GetPlayerPed(source)),
                isUrgent = true,
                isAnonymous = false
            }

            local xPlayers = ESX.GetPlayers()
            for _, playerId in ipairs(xPlayers) do
                local xTarget = ESX.GetPlayerFromId(playerId)
                if xTarget and Config.EmergencyJobs[xTarget.job.name] then
                    TriggerClientEvent('dispatch:receiveEmergencyCall', playerId, dispatchData)
                end
            end
            
            -- Notify the officer
            TriggerClientEvent('esx:showNotification', source, "Officer down alert has been dispatched.")
            return
        end

        -- Other emergency commands (911, 911a, 311, 311a)
        if #args == 0 then
            TriggerClientEvent('esx:showNotification', source, "Please include a message with your call.")
            return
        end
        
        local message = table.concat(args, " ")
        local isAnonymous = cmd:find('a', -1) ~= nil
        local isUrgent = cmd:find('911') ~= nil
        
        Debug('Processing %s call: Anonymous: %s, Urgent: %s', cmd, isAnonymous, isUrgent)
        
        -- Trigger client event to play animation
        TriggerClientEvent('emergency:playCallAnimation', source)
        
        -- Get caller information from database
        MySQL.query('SELECT firstname, lastname, phone_number FROM users WHERE identifier = ?', {
            xPlayer.identifier
        }, function(result)
            if not result[1] then return end
            
            local playerPed = GetPlayerPed(source)
            local coords = GetEntityCoords(playerPed)
            
            local dispatchData = {
                type = isUrgent and (isAnonymous and "ANONYMOUS 911" or "911 EMERGENCY") or 
                       (isAnonymous and "ANONYMOUS 311" or "311 NON-EMERGENCY"),
                caller = {
                    name = isAnonymous and "Anonymous" or 
                          string.format("%s %s", result[1].firstname, result[1].lastname),
                    phone = isAnonymous and "UNKNOWN" or result[1].phone_number or "NO PHONE"
                },
                message = message,
                coords = coords,
                isUrgent = isUrgent,
                isAnonymous = isAnonymous
            }

            Debug('Dispatch data prepared: %s', json.encode(dispatchData))

            -- Send to all emergency services
            local xPlayers = ESX.GetPlayers()
            for _, playerId in ipairs(xPlayers) do
                local xTarget = ESX.GetPlayerFromId(playerId)
                if xTarget and Config.EmergencyJobs[xTarget.job.name] then
                    TriggerClientEvent('dispatch:receiveEmergencyCall', playerId, dispatchData)
                end
            end
            
            -- Notify caller
            TriggerClientEvent('esx:showNotification', source, 
                ("%s call has been dispatched."):format(isAnonymous and "Anonymous" or "Your"))
        end)
    end)
end


-- Dispatch command
RegisterCommand('dispatch', function(source, args, rawCommand)
    Debug('Dispatch command triggered by source: %s', source)
    
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then 
        Debug('Invalid player tried to use dispatch')
        return 
    end
    
    if not Config.EmergencyJobs[xPlayer.job.name] then
        Debug('Unauthorized job tried to use dispatch: %s', xPlayer.job.name)
        TriggerClientEvent('esx:showNotification', source, "You do not have access to dispatch communications.")
        return
    end
    
    if #args == 0 then 
        Debug('Empty dispatch message')
        return 
    end
    
    local message = table.concat(args, " ")
    local callsign = activeCallsigns[source] and activeCallsigns[source].callsign or "NO CALLSIGN"
    local dispatchMessage = ("[%s] %s: %s"):format(xPlayer.job.name:upper(), callsign, message)
    
    Debug('Sending dispatch message: %s', dispatchMessage)
    TriggerClientEvent('dispatch:receiveMessage', -1, {
        message = dispatchMessage,
        job = xPlayer.job.name
    })
end)

-- Callsign command
RegisterCommand('callsign', function(source, args, rawCommand)
    Debug('Callsign command triggered by source: %s', source)
    
    local xPlayer = ESX.GetPlayerFromId(source)
    if not xPlayer then 
        Debug('Invalid player tried to set callsign')
        return 
    end
    
    if not Config.EmergencyJobs[xPlayer.job.name] then
        Debug('Unauthorized job tried to set callsign: %s', xPlayer.job.name)
        TriggerClientEvent('esx:showNotification', source, "Only emergency services can set callsigns.")
        return
    end
    
    if #args == 0 then
        Debug('No callsign provided')
        TriggerClientEvent('esx:showNotification', source, xPlayer.job.name == 'police' 
            and "Usage: /callsign [number] (e.g., 429)" 
            or "Usage: /callsign [letter-number] (e.g., A-31)")
        return
    end
    
    local callsign = args[1]:upper()
    Debug('Attempting to set callsign: %s for job: %s', callsign, xPlayer.job.name)
    
    if not Config.CallsignPatterns[xPlayer.job.name] then
        Debug('Invalid job type for callsign: %s', xPlayer.job.name)
        TriggerClientEvent('esx:showNotification', source, "Invalid job type for callsign.")
        return
    end
    
    if not string.match(callsign, Config.CallsignPatterns[xPlayer.job.name]) then
        Debug('Invalid callsign format: %s for job: %s', callsign, xPlayer.job.name)
        TriggerClientEvent('esx:showNotification', source, xPlayer.job.name == 'police'
            and "Invalid police callsign. Use numbers only (e.g., 429)."
            or "Invalid EMS callsign. Use format: Letter-Number (e.g., A-31)")
        return
    end
    
    MySQL.query('SELECT firstname, lastname FROM users WHERE identifier = ?', {
        xPlayer.identifier
    }, function(result)
        if result and result[1] then
            local callsignData = {
                callsign = callsign,
                name = ("%s %s"):format(result[1].firstname, result[1].lastname),
                job = xPlayer.job.name
            }
            
            Debug('Setting callsign data: %s', json.encode(callsignData))
            activeCallsigns[source] = callsignData
            TriggerClientEvent('dispatch:updateCallsigns', -1, activeCallsigns)
            TriggerClientEvent('esx:showNotification', source, ("Callsign set to: %s"):format(callsign))
        else
            Debug('Failed to get player name for callsign')
            TriggerClientEvent('esx:showNotification', source, "Failed to set callsign. Please try again.")
        end
    end)
end)

-- Add these exports for other resources to use
exports('GetActiveCallsigns', function()
    return activeCallsigns
end)

-- Cleanup handlers
AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        Debug('Resource stopping, cleaning up callsigns')
        activeCallsigns = {}
    end
end)

AddEventHandler('playerDropped', function()
    if activeCallsigns[source] then
        Debug('Player dropped, removing callsign for source: %s', source)
        activeCallsigns[source] = nil
        TriggerClientEvent('dispatch:updateCallsigns', -1, activeCallsigns)
    end
end)