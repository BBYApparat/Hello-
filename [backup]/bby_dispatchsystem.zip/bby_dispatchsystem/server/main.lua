ESX = exports["es_extended"]:getSharedObject()

Config.Debug = false

function Debug(message, ...)
    if Config.Debug then
        local args = {...}
        local formatted = string.format(message, table.unpack(args))
        print('^3[BBY-DISPATCH]^0: ' .. formatted)
    end
end

local activeCallsigns = {}

function IsValidCallsign(callsign, jobName)
    if not callsign or callsign == "" then return false end
    if #callsign > Config.MaxCallsignLength[jobName] then return false end
    return callsign:match(Config.CallsignPatterns[jobName]) ~= nil
end

function GetEmergencyPlayers()
    local emergencyPlayers = {}
    local xPlayers = ESX.GetPlayers()
    
    for _, playerId in ipairs(xPlayers) do
        local xPlayer = ESX.GetPlayerFromId(playerId)
        if Config.EmergencyJobs[xPlayer.job.name] then
            table.insert(emergencyPlayers, playerId)
        end
    end
    
    return emergencyPlayers
end

function SendToEmergencyServices(eventName, data)
    local emergencyPlayers = GetEmergencyPlayers()
    for _, playerId in ipairs(emergencyPlayers) do
        TriggerClientEvent(eventName, playerId, data)
    end
end

function UpdateCallsign(source, callsignData)
    if not activeCallsigns[source] then
        activeCallsigns[source] = {}
    end
    activeCallsigns[source] = callsignData
    SendToEmergencyServices('dispatch:updateCallsigns', activeCallsigns)
end

AddEventHandler('playerDropped', function()
    if activeCallsigns[source] then
        activeCallsigns[source] = nil
        SendToEmergencyServices('dispatch:updateCallsigns', activeCallsigns)
    end
end)

function SendDispatchMessage(source, message, isAnonymous, isUrgent)
    local playerInfo = nil
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not isAnonymous then
        local result = MySQL.query.await('SELECT firstname, lastname, phone_number, sex FROM users WHERE identifier = ?', {
            xPlayer.identifier
        })
        
        if result and result[1] then
            playerInfo = {
                name = result[1].firstname .. " " .. result[1].lastname,
                phone = result[1].phone_number,
                gender = result[1].sex
            }
        end
    else
        playerInfo = {
            name = "Anonymous",
            phone = "Unknown",
            gender = "Unknown"
        }
    end
    
    if not playerInfo then return end
    
    local ped = GetPlayerPed(source)
    local coords = GetEntityCoords(ped)
    
    local dispatchData = {
        message = message,
        coords = coords,
        urgent = isUrgent,
        caller = playerInfo,
        timestamp = os.time()
    }
    
    SendToEmergencyServices('dispatch:receiveCall', dispatchData)
end

RegisterNetEvent('dispatch:sendMessage')
AddEventHandler('dispatch:sendMessage', function(source, message, isAnonymous, isUrgent)
    SendDispatchMessage(source, message, isAnonymous, isUrgent)
end)

RegisterNetEvent('dispatch:updateCallsign')
AddEventHandler('dispatch:updateCallsign', function(source, callsignData)
    UpdateCallsign(source, callsignData)
end)

-- Add this export to get active callsigns
exports('GetActiveCallsigns', function()
    return activeCallsigns
end)