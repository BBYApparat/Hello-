ESX = exports["es_extended"]:getSharedObject()

function Debug(message, ...)
    if Config.Debug then
        local args = {...}
        local formatted = string.format(message, table.unpack(args))
        print('^3[BBY-DISPATCH:SERVER]^0: ' .. formatted)
    end
end

RegisterNetEvent('dispatch:reportCrime')
AddEventHandler('dispatch:reportCrime', function(data)
    local source = source
    Debug('Received crime report from source: %s, type: %s', source, data.type)
    
    -- ? TI stelnw
    if not data or not data.type or not Config.AutoDispatch[data.type] then
        Debug('Invalid data received')
        return
    end
    

    local dispatchConfig = Config.AutoDispatch[data.type]
    Debug('Using dispatch config for type: %s', data.type)
    

    local players = ESX.GetExtendedPlayers() -- Using GetExtendedPlayers instead of GetPlayers
    Debug('Found %s players online', #players)
    

    for _, xPlayer in pairs(players) do
        if xPlayer then
            for _, jobName in ipairs(dispatchConfig.jobs) do
                if xPlayer.job.name == jobName then
                    Debug('Sending alert to player %s with job %s', xPlayer.source, xPlayer.job.name)
                    TriggerClientEvent('dispatch:receiveCrime', xPlayer.source, data)
                    break
                end
            end
        end
    end
end)

-- Katharismo on resource stop
AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        Debug('Resource stopping, cleaning up...')
        -- Add any cleanup code here if needed
    end
end)