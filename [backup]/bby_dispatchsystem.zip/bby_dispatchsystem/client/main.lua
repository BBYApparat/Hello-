ESX = exports["es_extended"]:getSharedObject()

local PlayerData = {}
local activeBlips = {}
local activeCallsigns = {}
local emergencyMessages = {}
local displayDuration = 10000 -- 10 seconds

function Debug(message, ...)
    if Config.Debug then
        local args = {...}
        local formatted = string.format(message, table.unpack(args))
        print('^3[BBY-DISPATCH:NUI]^0: ' .. formatted)
    end
end

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
end)

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    PlayerData.job = job
    
    if not Config.EmergencyJobs[job.name] then
        for _, blip in pairs(activeBlips) do
            RemoveBlip(blip)
        end
        activeBlips = {}
    end
end)

function IsEmergencyServices()
    return PlayerData.job and Config.EmergencyJobs[PlayerData.job.name] or false
end

function CreateDispatchBlip(coords, isUrgent)
    if not IsEmergencyServices() then return end
    
    local blipSettings = isUrgent and Config.BlipSettings.emergency or Config.BlipSettings.nonEmergency
    local blip = AddBlipForCoord(coords.x, coords.y, coords.z)
    
    SetBlipSprite(blip, blipSettings.sprite)
    SetBlipScale(blip, blipSettings.scale)
    SetBlipColour(blip, blipSettings.color)
    SetBlipAsShortRange(blip, false)
    
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(blipSettings.name)
    EndTextCommandSetBlipName(blip)
    
    SetTimeout(Config.BlipDuration, function()
        RemoveBlip(blip)
    end)
    
    return blip
end

function UpdateOfficerBlip(playerId, callsignData)
    if not IsEmergencyServices() then return end
    
    if activeBlips[playerId] then
        RemoveBlip(activeBlips[playerId])
        activeBlips[playerId] = nil
    end
    
    local player = GetPlayerFromServerId(playerId)
    if player == -1 then return end
    
    local ped = GetPlayerPed(player)
    if not DoesEntityExist(ped) then return end
    
    local blip = AddBlipForEntity(ped)
    local blipConfig = Config.BlipSettings[callsignData.job]
    
    SetBlipSprite(blip, blipConfig.sprite)
    SetBlipScale(blip, blipConfig.scale)
    SetBlipColour(blip, blipConfig.color)
    SetBlipAsShortRange(blip, true)
    
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(("%s %s"):format(callsignData.callsign, callsignData.name))
    EndTextCommandSetBlipName(blip)
    
    activeBlips[playerId] = blip
end

RegisterNetEvent('dispatch:receiveEmergencyCall')
AddEventHandler('dispatch:receiveEmergencyCall', function(data)
    if not IsEmergencyServices() then return end
    Debug('Received emergency call data: %s', json.encode(data))
    
    -- Get street name
    local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(
        data.coords.x, 
        data.coords.y, 
        data.coords.z
    ))
    Debug('Street name for dispatch: %s', streetName)

    -- Prepare NUI data
    local nuiData = {
        type = 'dispatch',
        isUrgent = data.isUrgent,
        callType = data.type, -- This will be "911 EMERGENCY" or "311 NON-EMERGENCY"
        caller = data.caller.name, -- This now comes from the caller object
        phone = data.caller.phone, -- This now comes from the caller object
        location = streetName,
        message = data.message,
        time = "00:00",
        isAnonymous = data.isAnonymous
    }
    Debug('Sending NUI message: %s', json.encode(nuiData))

    -- Send to NUI
    SendNUIMessage(nuiData)
    
    -- Create blip
    if data.coords then
        Debug('Creating blip at coords: %s', json.encode(data.coords))
        CreateDispatchBlip(data.coords, data.isUrgent)
    end
    
    -- Play sound for emergency calls
    if data.isUrgent then
        Debug('Playing emergency sound')
        PlaySoundFrontend(-1, "SELECT", "HUD_FRONTEND_DEFAULT_SOUNDSET", false)
    end
end)

RegisterNetEvent('dispatch:updateCallsigns')
AddEventHandler('dispatch:updateCallsigns', function(newCallsigns)
    if not IsEmergencyServices() then return end
    
    activeCallsigns = newCallsigns
    
    for playerId, callsignData in pairs(activeCallsigns) do
        UpdateOfficerBlip(playerId, callsignData)
    end
    
    for playerId, blip in pairs(activeBlips) do
        if not activeCallsigns[playerId] then
            RemoveBlip(blip)
            activeBlips[playerId] = nil
        end
    end
end)

RegisterNetEvent('dispatch:receiveMessage')
AddEventHandler('dispatch:receiveMessage', function(data)
    if not IsEmergencyServices() then return end
    
    TriggerEvent('chat:addMessage', {
        template = '<div style="padding: 0.5vw; margin: 0.5vw; background-color: rgba({0}, {1}, {2}, 0.9); border-radius: 3px;"><i class="fas fa-bullhorn"></i> {3}</div>',
        args = { 
            Config.ChatColors.dispatch.r,
            Config.ChatColors.dispatch.g,
            Config.ChatColors.dispatch.b,
            data.message 
        }
    })
end)

-- Test command to verify NUI
RegisterCommand('testdispatch', function()
    if not IsEmergencyServices() then return end
    
    Debug('Testing dispatch NUI')
    SendNUIMessage({
        type = 'dispatch',
        isUrgent = true,
        callType = '911 EMERGENCY CALL',
        caller = 'Test Caller',
        phone = 'TEST-PHONE',
        location = 'Test Location',
        message = 'This is a test dispatch message'
    })
end)

-- Update officer blips thread
CreateThread(function()
    while true do
        Wait(1000)
        if IsEmergencyServices() then
            for playerId, callsignData in pairs(activeCallsigns) do
                UpdateOfficerBlip(playerId, callsignData)
            end
        end
    end
end)


RegisterNetEvent('emergency:playCallAnimation')
AddEventHandler('emergency:playCallAnimation', function()
    local playerPed = PlayerPedId()
    TaskStartScenarioInPlace(playerPed, 'WORLD_HUMAN_STAND_MOBILE', 0, true)
    Citizen.Wait(5000)  -- Animation duration (5 seconds)
    ClearPedTasks(playerPed)  -- Stop animation after duration
end)

RegisterNetEvent('emergency:playGunshotSound')
AddEventHandler('emergency:playGunshotSound', function()
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)

    -- Play gunshot sound for all players within a certain radius
    TriggerServerEvent('InteractSound_SV:PlayWithinDistance', 20.0, 'gunshots', 1.0)  -- 20m radius, full volume
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName == GetCurrentResourceName() then
        for _, blip in pairs(activeBlips) do
            RemoveBlip(blip)
        end
    end
end)

