ESX = exports["es_extended"]:getSharedObject()

local recentAlerts = {}

function Debug(message, ...)
    if Config.Debug then
        local args = {...}
        local formatted = string.format(message, table.unpack(args))
        print('^3[BBY-DISPATCH:AUTO]^0: ' .. formatted)
    end
end

function IsValid(entity)
    return entity ~= nil and DoesEntityExist(entity)
end

-- FExei jana sumvei?
function hasRecentAlert(type, coords)
    if not recentAlerts[type] then return false end
    
    local now = GetGameTimer()
    for i = #recentAlerts[type], 1, -1 do
        local alert = recentAlerts[type][i]
        if now - alert.time > Config.AutoDispatch[type].cooldown then
            table.remove(recentAlerts[type], i)
        elseif #(coords - alert.coords) < Config.AutoDispatch[type].radius then
            return true
        end
    end
    return false
end

-- Alerts
function addRecentAlert(type, coords)
    if not recentAlerts[type] then
        recentAlerts[type] = {}
    end
    table.insert(recentAlerts[type], {
        coords = coords,
        time = GetGameTimer()
    })
end

-- 10-71B
CreateThread(function()
    while true do
        Wait(10)
        local ped = PlayerPedId()
        
        -- Silencer
        if IsPedShooting(ped) and not IsPedCurrentWeaponSilenced(ped) then
            local coords = GetEntityCoords(ped)
            
            if not hasRecentAlert('shooting', coords) then
                addRecentAlert('shooting', coords)
                
                -- Odos?
                local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(coords.x, coords.y, coords.z))
                Debug('Detected shooting at %s', streetName)
                
                TriggerServerEvent('dispatch:reportCrime', {
                    type = 'shooting',
                    coords = coords,
                    street = streetName,
                    automatic = true
                })
                
                Wait(Config.AutoDispatch['shooting'].cooldown)
            end
        end
    end
end)

-- POn foot bail? Still under developing
-- CreateThread(function()
--     while true do
--         Wait(100)
--         local ped = PlayerPedId()
--         local playerCoords = GetEntityCoords(ped)
        
--         -- Check if player is sprinting and being chased
--         if IsPedSprinting(ped) or IsPedRunning(ped) then
--             -- Find nearby peds chasing the player
--             local isBeingChased = false
--             local found = GetGamePool('CPed')
            
--             for _, foundPed in ipairs(found) do
--                 if IsValid(foundPed) and not IsPedAPlayer(foundPed) then
--                     local pedState = GetPedAlertness(foundPed)
--                     if pedState and pedState > 0 then
--                         local pedCoords = GetEntityCoords(foundPed)
--                         if #(playerCoords - pedCoords) < 30.0 then
--                             isBeingChased = true
--                             break
--                         end
--                     end
--                 end
--             end
            
--             if isBeingChased and not hasRecentAlert('pursuit', playerCoords) then
--                 addRecentAlert('pursuit', playerCoords)
                
--                 local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(
--                     playerCoords.x, playerCoords.y, playerCoords.z
--                 ))
--                 Debug('Detected pursuit at %s', streetName)
                
--                 TriggerServerEvent('dispatch:reportCrime', {
--                     type = 'pursuit',
--                     coords = playerCoords,
--                     street = streetName,
--                     automatic = true
--                 })
                
--                 Wait(Config.AutoDispatch['pursuit'].cooldown)
--             end
--         end
--         Wait(1000)
--     end
-- end)

-- Handle incoming dispatch notifications
RegisterNetEvent('dispatch:receiveCrime')
AddEventHandler('dispatch:receiveCrime', function(data)
    if not ESX.PlayerData.job or not Config.EmergencyJobs[ESX.PlayerData.job.name] then 
        Debug('Player not emergency services, ignoring crime report')
        return 
    end
    
    local dispatchConfig = Config.AutoDispatch[data.type]
    if not dispatchConfig then 
        Debug('Invalid dispatch type: %s', data.type)
        return 
    end
    
    -- Police?
    local shouldReceive = false
    for _, job in ipairs(dispatchConfig.jobs) do
        if job == ESX.PlayerData.job.name then
            shouldReceive = true
            break
        end
    end
    
    if not shouldReceive then 
        Debug('Job %s not configured to receive %s alerts', ESX.PlayerData.job.name, data.type)
        return 
    end
    
    Debug('Processing crime report: %s at %s', data.type, data.street)

    SendNUIMessage({
        type = 'auto-dispatch',
        category = data.type,
        code = dispatchConfig.code,
        title = dispatchConfig.title,
        location = data.street,
        details = dispatchConfig.description,
        automatic = true
    })
    
    local blip = AddBlipForCoord(data.coords.x, data.coords.y, data.coords.z)
    SetBlipSprite(blip, dispatchConfig.blipSprite)
    SetBlipScale(blip, dispatchConfig.blipScale)
    SetBlipColour(blip, dispatchConfig.blipColor)
    SetBlipAsShortRange(blip, false)
    SetBlipFlashes(blip, true)
    
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(dispatchConfig.title)
    EndTextCommandSetBlipName(blip)
    
    PlaySoundFrontend(-1, "CONFIRM_BEEP", "HUD_MINI_GAME_SOUNDSET", false)
    
    SetTimeout(dispatchConfig.blipTimeout, function()
        RemoveBlip(blip)
    end)
end)