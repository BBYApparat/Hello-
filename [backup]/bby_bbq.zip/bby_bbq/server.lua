-- server.lua
ESX = exports["es_extended"]:getSharedObject()
local ox_inventory = exports.ox_inventory

-- Buy item from shop
RegisterNetEvent('bbqshop:buyItem')
AddEventHandler('bbqshop:buyItem', function(itemName, price)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    print("Player attempting to buy:", itemName, "for $" .. price) -- Debug print
    
    if not xPlayer then return end
    
    -- Verify the item exists in the config
    local itemFound = false
    for _, category in pairs({Config.BBQItems, Config.BBQMeatItems}) do
        for _, item in pairs(category) do
            if item.name == itemName and item.price == price then
                itemFound = true
                break
            end
        end
        if itemFound then break end
    end
    
    if not itemFound then
        print("Invalid item or price:", itemName, price)
        return
    end
    
    if xPlayer.getMoney() >= price then
        if exports.ox_inventory:CanCarryItem(source, itemName, 1) then
            xPlayer.removeMoney(price)
            exports.ox_inventory:AddItem(source, itemName, 1)
            TriggerClientEvent('ox_lib:notify', source, {
                title = 'Purchase Successful',
                description = 'You bought ' .. itemName,
                type = 'success'
            })
        else
            TriggerClientEvent('ox_lib:notify', source, {
                title = 'Cannot Carry',
                description = 'Inventory is full',
                type = 'error'
            })
        end
    else
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Insufficient Funds',
            description = 'Not enough money',
            type = 'error'
        })
    end
end)

-- Remove item when placing prop
RegisterNetEvent('bbqshop:removeItemOnPlace')
AddEventHandler('bbqshop:removeItemOnPlace', function(itemName)
    local source = source
    if exports.ox_inventory:GetItem(source, itemName, nil, true) > 0 then
        exports.ox_inventory:RemoveItem(source, itemName, 1)
    end
end)

-- Return item when picking up prop

RegisterNetEvent('bbqshop:returnItem')
AddEventHandler('bbqshop:returnItem', function(itemName)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    -- Check again if they can carry it (double check)
    if exports.ox_inventory:CanCarryItem(source, itemName, 1) then
        exports.ox_inventory:AddItem(source, itemName, 1)
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Item Retrieved',
            description = 'Added ' .. itemName .. ' to inventory',
            type = 'success'
        })
    else
        -- If they somehow can't carry it, spawn it on the ground
        local playerCoords = GetEntityCoords(GetPlayerPed(source))
        
        -- Create the item on the ground using ox_inventory
        exports.ox_inventory:CustomDrop(itemName .. '_' .. math.random(1000, 9999), {
            {name = itemName, count = 1}
        }, playerCoords)
        
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Inventory Full',
            description = 'Item dropped on ground',
            type = 'warning'
        })
    end
end)

lib.callback.register('bbqshop:canCarryItem', function(source, itemName)
    return exports.ox_inventory:CanCarryItem(source, itemName, 1)
end)

RegisterNetEvent('bbqshop:removeMeatItem')
AddEventHandler('bbqshop:removeMeatItem', function(foodName)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    -- Verify item exists in config
    local isValidMeat = false
    for _, item in pairs(Config.BBQMeatItems) do
        if item.name == foodName then
            isValidMeat = true
            break
        end
    end
    
    if not isValidMeat then
        print("Invalid meat item:", foodName)
        return
    end
    
    exports.ox_inventory:RemoveItem(source, foodName, 1)
end)

RegisterNetEvent('bbqshop:giveCookedItem')
AddEventHandler('bbqshop:giveCookedItem', function(foodName)
    local source = source
    
    if exports.ox_inventory:CanCarryItem(source, foodName .. "_cooked", 1) then
        exports.ox_inventory:AddItem(source, foodName .. "_cooked", 1)
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Cooking Complete',
            description = 'You received a cooked ' .. foodName,
            type = 'success'
        })
    end
end)

RegisterNetEvent('bbqshop:giveBurntItem')
AddEventHandler('bbqshop:giveBurntItem', function(foodName)
    local source = source
    
    if exports.ox_inventory:CanCarryItem(source, foodName .. "_burnt", 1) then
        exports.ox_inventory:AddItem(source, foodName .. "_burnt", 1)
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Cooking Failed',
            description = 'The ' .. foodName .. ' got burnt!',
            type = 'error'
        })
    end
end)

-- Handle soda machine interaction
RegisterNetEvent('bbqshop:makeSoda')
AddEventHandler('bbqshop:makeSoda', function(flavor)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    
    if not xPlayer then return end
    
    local selectedFlavor = nil
    for _, flavorConfig in pairs(Config.SodaFlavors) do
        if flavorConfig.name == flavor then
            selectedFlavor = flavorConfig
            break
        end
    end
    
    if not selectedFlavor then
        TriggerClientEvent('ox_lib:notify', source, {
            title = 'Invalid Flavor',
            description = 'This soda flavor doesn\'t exist',
            type = 'error'
        })
        return
    end
    
    -- Check ingredients
    local hasAllIngredients = true
    for _, ingredient in pairs(selectedFlavor.ingredients) do
        if exports.ox_inventory:GetItem(source, ingredient, nil, true) <= 0 then
            hasAllIngredients = false
            TriggerClientEvent('ox_lib:notify', source, {
                title = 'Missing Ingredient',
                description = 'You need ' .. ingredient,
                type = 'error'
            })
            break
        end
    end
    
    if hasAllIngredients then
        -- Remove ingredients
        for _, ingredient in pairs(selectedFlavor.ingredients) do
            exports.ox_inventory:RemoveItem(source, ingredient, 1)
        end
        
        -- Give soda
        local sodaItemName = flavor .. "_soda"
        if exports.ox_inventory:CanCarryItem(source, sodaItemName, 1) then
            exports.ox_inventory:AddItem(source, sodaItemName, 1)
            TriggerClientEvent('ox_lib:notify', source, {
                title = 'Soda Created',
                description = 'You made a ' .. selectedFlavor.label .. ' soda',
                type = 'success'
            })
        else
            TriggerClientEvent('ox_lib:notify', source, {
                title = 'Cannot Carry',
                description = 'Inventory is full',
                type = 'error'
            })
        end
    end
end)

-- Initialize usable items
CreateThread(function()
    -- Register equipment items
    for _, item in pairs(Config.BBQItems) do
        ESX.RegisterUsableItem(item.name, function(playerId)
            TriggerClientEvent('bbqshop:placeProp', playerId, item.name)
        end)
    end
    
    -- Register meat items for cooking
    for _, item in pairs(Config.BBQMeatItems) do
        ESX.RegisterUsableItem(item.name, function(playerId)
            -- Check if player is near a BBQ
            TriggerClientEvent('bbqshop:checkBBQDistance', playerId, item.name)
        end)
    end
end)

lib.callback.register('bbqshop:canCarryItem', function(source, itemName)
    local xPlayer = ESX.GetPlayerFromId(source)
    return exports.ox_inventory:CanCarryItem(source, itemName, 1)
end)

exports.ox_inventory:RegisterStash('bbq_storage', 'BBQ Storage', 20, 1000000)

RegisterNetEvent('bbqshop:giveRawItem')
AddEventHandler('bbqshop:giveRawItem', function(foodName)
    local source = source
    if exports.ox_inventory:CanCarryItem(source, foodName .. "_raw", 1) then
        exports.ox_inventory:AddItem(source, foodName .. "_raw", 1)
        lib.notify({
            title = 'Item Taken',
            description = 'You took the raw ' .. foodName,
            type = 'success'
        })
    end
end)

RegisterNetEvent('bbqshop:giveRareItem')
AddEventHandler('bbqshop:giveRareItem', function(foodName)
    local source = source
    if exports.ox_inventory:CanCarryItem(source, foodName .. "_rare", 1) then
        exports.ox_inventory:AddItem(source, foodName .. "_rare", 1)
        lib.notify({
            title = 'Item Taken',
            description = 'You took the rare ' .. foodName,
            type = 'success'
        })
    end
end)

RegisterNetEvent('bbqshop:giveMediumItem')
AddEventHandler('bbqshop:giveMediumItem', function(foodName)
    local source = source
    if exports.ox_inventory:CanCarryItem(source, foodName .. "_medium", 1) then
        exports.ox_inventory:AddItem(source, foodName .. "_medium", 1)
        lib.notify({
            title = 'Item Taken',
            description = 'You took the medium ' .. foodName,
            type = 'success'
        })
    end
end)

RegisterNetEvent('bbqshop:giveFinalSoda')
AddEventHandler('bbqshop:giveFinalSoda', function(sodaItem)
    local source = source
    exports.ox_inventory:AddItem(source, sodaItem, 1)
end)

RegisterNetEvent('bbqshop:removeSodaItems')
AddEventHandler('bbqshop:removeSodaItems', function(items)
    local source = source
    exports.ox_inventory:RemoveItem(source, 'cup', 1)
    exports.ox_inventory:RemoveItem(source, items.syrup.name, 1)
end)

RegisterNetEvent('bbqshop:returnSodaItems')
AddEventHandler('bbqshop:returnSodaItems', function(items)
    local source = source
    exports.ox_inventory:AddItem(source, 'cup', 1)
    exports.ox_inventory:AddItem(source, items.syrup.name, 1)
end)