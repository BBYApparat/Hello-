ESX = exports["es_extended"]:getSharedObject()
local ox_lib = exports.ox_lib

local placedProps = {}
local currentProp = nil
local isPlacing = false
local propOffsetZ = 0.0
local propRotation = 0.0
local activeCookingItems = {}
local smoke = nil



-- Function to create the BBQ NPC with ox_target interaction
CreateThread(function()
    local npcCoords = vector3(168.6, -989.5, 29.98)
    local model = `s_m_m_linecook`
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(0)
    end

    local npc = CreatePed(4, model, npcCoords.x, npcCoords.y, npcCoords.z, 180.0, false, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    TaskStartScenarioInPlace(npc, "WORLD_HUMAN_SMOKING", 0, true)
    
    exports.ox_target:addLocalEntity(npc, {
        {
            name = 'bbqshop_interact',
            label = 'BBQ Shop',
            icon = 'fa-solid fa-store',
            onSelect = function()
                OpenBBQShop()
            end
        }
    })
end)

function PickUpPropWithAnimation(propEntity, propName)
    if not DoesEntityExist(propEntity) then return end

    -- Store the entity handle before checking inventory
    local entityHandle = propEntity
    
    -- Check if player can carry the item first
    local canCarry = lib.callback.await('bbqshop:canCarryItem', false, propName)
    if not canCarry then
        lib.notify({
            title = 'Inventory Full',
            description = 'You cannot carry this item!',
            type = 'error'
        })
        return
    end

    local playerPed = PlayerPedId()
    
    -- Start pickup animation
    local dict = "anim@heists@narcotics@trash"
    local anim = "pickup"
    
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(100)
    end

    -- Start progress bar and animation
    TaskPlayAnim(playerPed, dict, anim, 8.0, -8.0, -1, 1, 0, false, false, false)
    
    local success = lib.progressCircle({
        duration = 2000,
        label = 'Picking up ' .. propName,
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        disable = {
            car = true,
            move = true,
            combat = true
        },
        anim = {
            dict = dict,
            clip = anim
        },
    })

    ClearPedTasks(playerPed)

    if success then
        -- Double check if entity still exists
        if DoesEntityExist(entityHandle) then
            -- Remove from ox_target first
            exports.ox_target:removeLocalEntity(entityHandle)
            
            -- Set as no longer needed
            SetEntityAsMissionEntity(entityHandle, true, true)
            
            -- Delete the entity
            DeleteEntity(entityHandle)
            
            -- Force remove if still exists
            if DoesEntityExist(entityHandle) then
                DeleteObject(entityHandle)
            end

            -- Remove from tracking table
            for i, prop in ipairs(placedProps) do
                if prop.entity == entityHandle then
                    table.remove(placedProps, i)
                    break
                end
            end
            
            -- Give item back
            TriggerServerEvent('bbqshop:returnItem', propName)
            
            lib.notify({
                title = 'Success',
                description = 'Picked up ' .. propName,
                type = 'success'
            })
        end
    end
end

function OpenBBQShop()
    print("Opening BBQ Shop Menu") -- Debug print
    
    local options = {
        {
            title = 'BBQ Equipment',
            description = 'Purchase BBQ equipment and furniture',
            onSelect = function()
                OpenEquipmentMenu()
            end,
            arrow = true
        },
        {
            title = 'BBQ Meat',
            description = 'Purchase meat for cooking',
            onSelect = function()
                OpenMeatMenu()
            end,
            arrow = true
        }
    }

    lib.registerContext({
        id = 'bbq_shop_main',
        title = 'BBQ Shop',
        options = options
    })

    lib.showContext('bbq_shop_main')
end

function OpenEquipmentMenu()
    local options = {}
    for _, item in pairs(Config.BBQItems) do
        table.insert(options, {
            title = item.label,
            description = ('$%s'):format(item.price),
            onSelect = function()
                TriggerServerEvent('bbqshop:buyItem', item.name, item.price)
            end,
            arrow = true
        })
    end

    lib.registerContext({
        id = 'bbq_equipment_menu',
        title = 'BBQ Equipment',
        menu = 'bbq_shop_main',
        options = options
    })

    lib.showContext('bbq_equipment_menu')
end

function OpenMeatMenu()
    local options = {}
    for _, item in pairs(Config.BBQMeatItems) do
        table.insert(options, {
            title = item.label,
            description = ('$%s'):format(item.price),
            onSelect = function()
                TriggerServerEvent('bbqshop:buyItem', item.name, item.price)
            end,
            arrow = true
        })
    end

    lib.registerContext({
        id = 'bbq_meat_menu',
        title = 'BBQ Meat',
        menu = 'bbq_shop_main',
        options = options
    })

    lib.showContext('bbq_meat_menu')
end

function PlaceFinalProp(propName)
    isPlacing = false
    FreezeEntityPosition(currentProp, true)
    SetEntityAlpha(currentProp, 255, false)
    
    -- Set as mission entity
    SetEntityAsMissionEntity(currentProp, true, true)
    
    -- Store the prop in our tracking table with handle
    local propHandle = currentProp
    table.insert(placedProps, {
        entity = propHandle,
        type = propName
    })
    
    if propName == "bbq_stove" then
        exports.ox_target:addLocalEntity(propHandle, {
            {
                name = 'bbq_cook',
                label = 'Cook Food',
                icon = 'fa-solid fa-fire',
                onSelect = function()
                    OpenCookingMenu()
                end
            },
            {
                name = 'pick_up_bbq',
                label = 'Pick Up BBQ',
                icon = 'fa-solid fa-hand',
                onSelect = function()
                    PickUpPropWithAnimation(propHandle, 'bbq_stove')
                end
            }
        })
    elseif propName == "soda_machine" then
        -- Add debug print to verify this section is reached
        print("^2[DEBUG] Adding target options to soda machine^7")
        
        exports.ox_target:addLocalEntity(propHandle, {
            {
                name = 'dispense_soda',
                label = 'Dispense Soda',
                icon = 'fas fa-glass',
                distance = 2.0,
                onSelect = function()
                    print("^2[DEBUG] Soda machine target selected^7")
                    OpenSodaMenu()
                end
            },
            {
                name = 'pick_up_soda_machine',
                label = 'Pick Up Soda Machine',
                icon = 'fas fa-hand',
                distance = 2.0,
                onSelect = function()
                    print("^2[DEBUG] Pickup soda machine selected^7")
                    PickUpPropWithAnimation(propHandle, 'soda_machine')
                end
            }
        })
    else
        -- Regular prop pickup
        exports.ox_target:addLocalEntity(propHandle, {
            {
                name = 'pick_up_' .. propName,
                label = 'Pick Up',
                icon = 'fa-solid fa-hand',
                onSelect = function()
                    PickUpPropWithAnimation(propHandle, propName)
                end
            }
        })
    end

    TriggerServerEvent('bbqshop:removeItemOnPlace', propName)
    currentProp = nil
end

-- Start placing a prop
RegisterNetEvent('bbqshop:placeProp')
AddEventHandler('bbqshop:placeProp', function(propName)
    if isPlacing then return end
    
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    
    local propModels = {
        bbq_stove = "prop_bbq_1",
        table = "prop_table_04",
        chair = "prop_chair_08",
        soda_machine = "prop_food_cb_soda_02"
    }
    
    if not propModels[propName] then
        print("Invalid prop name:", propName)
        return
    end

    local propHash = GetHashKey(propModels[propName])
    RequestModel(propHash)
    while not HasModelLoaded(propHash) do
        Wait(0)
    end

    currentProp = CreateObject(propHash, playerCoords.x, playerCoords.y, playerCoords.z, false, false, false)
    FreezeEntityPosition(currentProp, true)
    SetEntityAlpha(currentProp, 150, false)
    
    isPlacing = true
    propOffsetZ = 0.0
    propRotation = 0.0

    CreateThread(function()
        while isPlacing do
            Wait(0)
            local forwardOffset = 1.0
            local newCoords = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, forwardOffset, propOffsetZ)
            SetEntityCoords(currentProp, newCoords.x, newCoords.y, newCoords.z, false, false, false, true)
            SetEntityHeading(currentProp, GetEntityHeading(playerPed) + propRotation)

            if IsControlPressed(0, 172) then -- Arrow Up
                propOffsetZ = propOffsetZ + 0.01
            elseif IsControlPressed(0, 173) then -- Arrow Down
                propOffsetZ = propOffsetZ - 0.01
            end

            if IsControlPressed(0, 174) then -- Arrow Left
                propRotation = propRotation - 1.0
            elseif IsControlPressed(0, 175) then -- Arrow Right
                propRotation = propRotation + 1.0
            end

            if IsControlJustPressed(0, 38) then -- E key
                PlaceFinalProp(propName)
            end

            -- Add cancel option
            if IsControlJustPressed(0, 177) then -- Backspace
                DeleteEntity(currentProp)
                isPlacing = false
                currentProp = nil
            end

            lib.showTextUI('[E] Place | [↑/↓] Height | [←/→] Rotate | [BACKSPACE] Cancel')
        end
        lib.hideTextUI()
    end)
end)



-- Add a cleanup function to make sure props are properly deleted:

function CleanupProp(propHandle)
    if not DoesEntityExist(propHandle) then return end
    
    -- Remove ox_target
    exports.ox_target:removeLocalEntity(propHandle)
    
    -- Set as mission entity
    SetEntityAsMissionEntity(propHandle, true, true)
    
    -- Delete entity
    DeleteEntity(propHandle)
    
    -- Force delete if still exists
    if DoesEntityExist(propHandle) then
        DeleteObject(propHandle)
    end
end



function OpenCookingMenu()
    print("Opening Cooking Menu") -- Debug print
    
    -- Initialize options array
    local options = {}
    
    -- Get the player's inventory items first
    local inventory = exports.ox_inventory:GetPlayerItems()
    if not inventory then 
        print("Failed to get inventory")
        return 
    end

    -- Create menu options from available meat items
    for _, item in pairs(Config.BBQMeatItems) do
        -- Check if player has this meat item
        for _, invItem in pairs(inventory) do
            if invItem.name == item.name and invItem.count > 0 then
                table.insert(options, {
                    title = item.label,
                    description = 'You have ' .. invItem.count .. ' ' .. item.label,
                    arrow = true,
                    event = 'bbqshop:startCooking',
                    args = { foodName = item.name }
                })
                break
            end
        end
    end

    -- Check if we have any options
    if #options == 0 then
        lib.notify({
            title = 'No meat available',
            description = 'You need to buy some meat first!',
            type = 'error'
        })
        return
    end

    -- Create the context menu
    lib.registerContext({
        id = 'bbq_cooking_menu',
        title = 'BBQ Cooking',
        options = options,
        onExit = function()
            print("Closed cooking menu")
        end
    })

    -- Show the menu
    lib.showContext('bbq_cooking_menu')
end

RegisterNetEvent('bbqshop:startCooking')
AddEventHandler('bbqshop:startCooking', function(data)
    print("Starting cooking process with data:", json.encode(data)) -- Debug print
    if not data or not data.foodName then 
        print("Invalid cooking data received")
        return 
    end
    StartCookingProcess(data.foodName)
end)

-- Add these meat model mappings at the top of your client.lua with other variables
local meatModels = {
    steak = "prop_cs_steak",
    pork_chops = "prop_cs_steak", -- Using steak prop as fallback
    sausages = "prop_cs_hotdog_01",
    chicken_wings = "prop_cs_steak" -- Using steak prop as fallback
}

function StartCookingProcess(foodName)
    print("^2[DEBUG] Starting cooking process for: " .. foodName .. "^7")

    local foodItem = nil
    for _, item in pairs(Config.BBQMeatItems) do
        if item.name == foodName then
            foodItem = item
            break
        end
    end
    
    if not foodItem then 
        lib.notify({
            title = 'Error',
            description = 'Invalid food item',
            type = 'error'
        })
        return 
    end

    -- Check if player has the item
    local count = exports.ox_inventory:Search('count', foodName)
    if count <= 0 then
        lib.notify({
            title = 'Missing Item',
            description = 'You need ' .. foodItem.label .. ' to cook!',
            type = 'error'
        })
        return
    end

    -- Check BBQ distance
    local playerPed = PlayerPedId()
    local bbqObj = nil
    local bbqCoords = nil
    
    for _, prop in pairs(placedProps) do
        if DoesEntityExist(prop.entity) and prop.type == "bbq_stove" then
            local propCoords = GetEntityCoords(prop.entity)
            local distance = #(GetEntityCoords(playerPed) - propCoords)
            if distance <= 2.0 then
                bbqObj = prop.entity
                bbqCoords = propCoords
                break
            end
        end
    end

    if not bbqObj or not bbqCoords then
        lib.notify({
            title = 'Too Far',
            description = 'You need to be closer to the BBQ!',
            type = 'error'
        })
        return
    end

    -- Start BBQ Animation
    local dict = "amb@prop_human_bbq@male@idle_a"
    local anim = "idle_a"
    
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(100)
    end
    
    TaskPlayAnim(playerPed, dict, anim, 8.0, -8.0, -1, 1, 0, false, false, false)

    -- Remove the raw item
    TriggerServerEvent('bbqshop:removeMeatItem', foodName)

    -- Create and attach spatula
    local spatulaHash = GetHashKey("prop_cs_fork")
    RequestModel(spatulaHash)
    while not HasModelLoaded(spatulaHash) do
        Wait(100)
    end

    local spatulaProp = CreateObject(spatulaHash, 0, 0, 0, true, true, true)
    AttachEntityToEntity(spatulaProp, playerPed, GetPedBoneIndex(playerPed, 57005),
        0.08, 0.0, -0.02, 265.0, 145.0, 0.0, true, true, false, true, 1, true)

    -- Create meat prop
    local meatModel = GetHashKey(meatModels[foodName] or "prop_cs_steak")
    RequestModel(meatModel)
    while not HasModelLoaded(meatModel) do
        Wait(100)
    end

    local bbqOffset = GetOffsetFromEntityInWorldCoords(bbqObj, 0.0, 0.0, 1.0)
    local meatProp = CreateObject(meatModel, bbqOffset.x, bbqOffset.y, bbqOffset.z, true, false, false)
    FreezeEntityPosition(meatProp, true)

    -- Initialize particle effects
    local particles = {}
    
    -- Request particle effects
    RequestNamedPtfxAsset("core")
    while not HasNamedPtfxAssetLoaded("core") do
        Wait(100)
    end
    
    UseParticleFxAssetNextCall("core")
    
    -- Add smoke particle
    local smokeCoords = GetOffsetFromEntityInWorldCoords(bbqObj, 0.0, 0.0, 1.0)
    particles.smoke = StartParticleFxLoopedAtCoord(
        "ent_amb_smoke_general", 
        smokeCoords.x, smokeCoords.y, smokeCoords.z + 0.2, 
        0.0, 0.0, 0.0, 
        0.8, -- Scale
        false, false, false, false
    )
    
    -- Add sparks particle
    UseParticleFxAssetNextCall("core")
    particles.sparks = StartParticleFxLoopedAtCoord(
        "ent_amb_sparking_wires", 
        smokeCoords.x, smokeCoords.y, smokeCoords.z, 
        0.0, 0.0, 0.0, 
        0.5, -- Scale
        false, false, false, false
    )

    -- Start the cooking process with circle progress bar
    local success = lib.progressCircle({
        duration = 20000,  -- 20 seconds total cooking time
        label = 'Cooking ' .. foodItem.label,
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        disable = {
            car = true,
            combat = true
        },
        anim = {
            dict = dict,
            clip = anim
        }
    })

    -- Cleanup function for particles
    local function cleanupParticles()
        for _, particle in pairs(particles) do
            if particle then
                StopParticleFxLooped(particle, 0)
            end
        end
    end

    if success then
        -- Cooking completed successfully
        lib.notify({
            title = 'Cooking Complete',
            description = foodItem.label .. ' is ready!',
            type = 'success'
        })
        
        -- Add final sizzle effect
        UseParticleFxAssetNextCall("core")
        local sizzle = StartParticleFxLoopedAtCoord(
            "ent_amb_steam_pipe", 
            smokeCoords.x, smokeCoords.y, smokeCoords.z + 0.2, 
            0.0, 0.0, 0.0, 
            1.0, 
            false, false, false, false
        )
        
        Wait(1000) -- Let the sizzle effect play for a second
        StopParticleFxLooped(sizzle, 0)
        
        -- Give cooked item
        TriggerServerEvent('bbqshop:giveCookedItem', foodName)
    else
        -- Cooking was cancelled
        lib.notify({
            title = 'Cooking Cancelled',
            description = 'You stopped cooking ' .. foodItem.label,
            type = 'error'
        })
        
        -- Return raw item
        TriggerServerEvent('bbqshop:giveMeatItem', foodName)
    end

    -- Cleanup
    cleanupParticles()
    DeleteEntity(meatProp)
    DeleteEntity(spatulaProp)
    ClearPedTasks(playerPed)
end

function RemoveMeat(index)
    local item = activeCookingItems[index]
    if not item then return end

    if item.status == "cooking" then
        lib.notify({
            title = 'Not Ready',
            description = 'The meat is still cooking!',
            type = 'error'
        })
        return
    end

    -- Give the appropriate item based on status
    if item.status == "ready" then
        TriggerServerEvent('bbqshop:giveCookedItem', item.name)
    elseif item.status == "burnt" then
        TriggerServerEvent('bbqshop:giveBurntItem', item.name)
    end

    -- Clean up props
    if DoesEntityExist(item.prop) then
        DeleteEntity(item.prop)
    end
    if DoesEntityExist(item.spatula) then
        DeleteEntity(item.spatula)
    end
    if item.smoke then
        StopParticleFxLooped(item.smoke, 0)
    end

    table.remove(activeCookingItems, index)
    
    ClearPedTasks(PlayerPedId())
end

RegisterNetEvent('bbqshop:useSodaMachine')
AddEventHandler('bbqshop:useSodaMachine', function()
    print("^2[DEBUG] Soda machine use event triggered^7")
    OpenSodaMenu()
end)

function OpenSodaMenu()
    print("^2[DEBUG] Opening Soda Menu^7") -- Debug print
    
    -- Get player's inventory to check for ingredients
    local inventory = exports.ox_inventory:GetPlayerItems()
    local options = {}
    
    for _, flavor in pairs(Config.SodaFlavors) do
        -- Check if player has required ingredients
        local hasCup = exports.ox_inventory:Search('count', 'cup') > 0
        local hasSyrup = exports.ox_inventory:Search('count', flavor.name..'_syrup') > 0
        
        local description = flavor.label
        if not hasCup then
            description = description .. ' (Missing: Cup)'
        end
        if not hasSyrup then
            description = description .. ' (Missing: ' .. flavor.label .. ' Syrup)'
        end
        
        table.insert(options, {
            title = flavor.label,
            description = description,
            disabled = not (hasCup and hasSyrup),
            onSelect = function()
                StartSodaProcess(flavor.name)
            end,
            arrow = true
        })
    end

    lib.registerContext({
        id = 'soda_machine_menu',
        title = 'Soda Machine',
        options = options
    })

    lib.showContext('soda_machine_menu')
end

function StartSodaProcess(sodaType)
    print("^2[DEBUG] Starting soda dispensing process for: " .. sodaType .. "^7")

    -- Map soda types to their final item names
    local sodaItems = {
        cola = "cola_soda",
        lemon_lime = "lemon_lime_soda",
        orange = "orange_soda"
    }

    -- Find the soda flavor data
    local sodaData = nil
    for _, flavor in pairs(Config.SodaFlavors) do
        if flavor.name == sodaType then
            sodaData = flavor
            break
        end
    end
    
    if not sodaData then 
        lib.notify({
            title = 'Error',
            description = 'Invalid soda flavor',
            type = 'error'
        })
        return 
    end

    -- Check if player has required items (cup and syrup)
    local hasCup = exports.ox_inventory:Search('count', 'cup')
    local hasSyrup = exports.ox_inventory:Search('count', sodaType..'_syrup')
    
    if hasCup <= 0 then
        lib.notify({
            title = 'Missing Item',
            description = 'You need a cup to pour soda!',
            type = 'error'
        })
        return
    end
    
    if hasSyrup <= 0 then
        lib.notify({
            title = 'Missing Item',
            description = 'You need '..sodaData.label..' syrup!',
            type = 'error'
        })
        return
    end

    -- Check soda machine distance
    local playerPed = PlayerPedId()
    local sodaMachine = nil
    local machineCoords = nil
    
    for _, prop in pairs(placedProps) do
        if DoesEntityExist(prop.entity) and prop.type == "soda_machine" then
            local propCoords = GetEntityCoords(prop.entity)
            local distance = #(GetEntityCoords(playerPed) - propCoords)
            if distance <= 2.0 then
                sodaMachine = prop.entity
                machineCoords = propCoords
                break
            end
        end
    end

    if not sodaMachine or not machineCoords then
        lib.notify({
            title = 'Too Far',
            description = 'You need to be closer to the soda machine!',
            type = 'error'
        })
        return
    end

    -- Start Soda Pouring Animation
    local dict = "mp_ped_interaction"
    local anim = "handshake_guy_a"  -- This animation shows hands moving similar to handling a cup
    
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Wait(100)
    end
    
    -- Create cup prop
    local cupModel = GetHashKey("prop_plastic_cup_02")
    RequestModel(cupModel)
    while not HasModelLoaded(cupModel) do
        Wait(100)
    end

    local cupProp = CreateObject(cupModel, 0.0, 0.0, 0.0, true, true, true)
    AttachEntityToEntity(cupProp, playerPed, GetPedBoneIndex(playerPed, 28422),
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)

    -- Initialize particle effects
    local particles = {}
    
    -- Request particle effects
    RequestNamedPtfxAsset("core")
    while not HasNamedPtfxAssetLoaded("core") do
        Wait(100)
    end
    
    UseParticleFxAssetNextCall("core")
    
    -- Add liquid pouring particle
    local pourCoords = GetOffsetFromEntityInWorldCoords(sodaMachine, 0.0, 0.3, 0.5)
    particles.pour = StartParticleFxLoopedAtCoord(
        "ent_sht_water", 
        pourCoords.x, pourCoords.y, pourCoords.z, 
        -90.0, 0.0, 0.0, 
        0.5, -- Scale
        false, false, false, false
    )
    
    -- Add fizz/bubble particle
    UseParticleFxAssetNextCall("core")
    particles.bubbles = StartParticleFxLoopedAtCoord(
        "ent_amb_fountain", 
        pourCoords.x, pourCoords.y, pourCoords.z - 0.2, 
        0.0, 0.0, 0.0, 
        0.3, -- Scale
        false, false, false, false
    )

    -- Remove required items first
    TriggerServerEvent('bbqshop:removeSodaItems', {
        cup = 1,
        syrup = {name = sodaType..'_syrup', count = 1}
    })

    -- Start the dispensing process with circle progress bar
    local success = lib.progressCircle({
        duration = 5000,  -- 5 seconds to fill cup
        label = 'Dispensing ' .. sodaData.label,
        position = 'bottom',
        useWhileDead = false,
        canCancel = true,
        disable = {
            car = true,
            combat = true
        },
        anim = {
            dict = dict,
            clip = anim
        }
    })

    -- Cleanup function for particles
    local function cleanupParticles()
        for _, particle in pairs(particles) do
            if particle then
                StopParticleFxLooped(particle, 0)
            end
        end
    end

    if success then
        -- Dispensing completed successfully
        lib.notify({
            title = 'Soda Ready',
            description = 'You made a ' .. sodaData.label .. '!',
            type = 'success'
        })
        
        -- Add final fizz effect
        UseParticleFxAssetNextCall("core")
        local finalFizz = StartParticleFxLoopedAtCoord(
            "ent_sht_soda_foam", 
            pourCoords.x, pourCoords.y, pourCoords.z, 
            0.0, 0.0, 0.0, 
            0.5, 
            false, false, false, false
        )
        
        Wait(1000) -- Let the fizz effect play for a second
        StopParticleFxLooped(finalFizz, 0)
        
        -- Give the correct soda item based on the type
        local finalSodaItem = sodaItems[sodaType]
        if finalSodaItem then
            TriggerServerEvent('bbqshop:giveFinalSoda', finalSodaItem)
        else
            print("^1[ERROR] No matching soda item found for type: " .. sodaType .. "^7")
        end
    else
        -- Dispensing was cancelled
        lib.notify({
            title = 'Dispensing Cancelled',
            description = 'You stopped making ' .. sodaData.label,
            type = 'error'
        })
        
        -- Return items
        TriggerServerEvent('bbqshop:returnSodaItems', {
            cup = 1,
            syrup = {name = sodaType..'_syrup', count = 1}
        })
    end

    -- Cleanup
    cleanupParticles()
    DeleteEntity(cupProp)
    ClearPedTasks(playerPed)
end

-- Add this to your existing ox_target setup for soda machine
exports.ox_target:addLocalEntity(propHandle, {
    {
        name = 'dispense_soda',
        label = 'Dispense Soda',
        icon = 'fa-solid fa-glass-water',
        onSelect = function()
            OpenSodaMenu()
        end
    },
    {
        name = 'pick_up_soda_machine',
        label = 'Pick Up Machine',
        icon = 'fa-solid fa-hand',
        onSelect = function()
            PickUpPropWithAnimation(propHandle, 'soda_machine')
        end
    }
})

function OpenSodaMenu()
    local options = {}
    
    for _, flavor in pairs(Config.SodaFlavors) do
        table.insert(options, {
            title = flavor.label,
            description = 'Make a ' .. flavor.label .. ' (Requires: Cup, ' .. flavor.label .. ' Syrup)',
            onSelect = function()
                StartSodaProcess(flavor.name)
            end,
            arrow = true
        })
    end

    lib.registerContext({
        id = 'soda_machine_menu',
        title = 'Soda Machine',
        options = options
    })

    lib.showContext('soda_machine_menu')
end


-- Add command to delete all props
RegisterCommand('clearbbq', function()
    local playerPed = PlayerPedId()
    local count = 0
    
    for i = #placedProps, 1, -1 do
        local prop = placedProps[i]
        if DoesEntityExist(prop.entity) then
            DeleteEntity(prop.entity)
            TriggerServerEvent('bbqshop:returnItem', prop.type)
            count = count + 1
        end
        table.remove(placedProps, i)
    end
    
    lib.notify({
        title = 'BBQ Cleanup',
        description = string.format('Removed %d props', count),
        type = 'success'
    })
end, false)

-- Add a restricted command for admins only
RegisterCommand('clearallbbq', function()
    if IsPlayerAceAllowed(PlayerId(), 'command.clearallbbq') then
        local count = 0
        local props = GetGamePool('CObject')
        
        for _, entity in ipairs(props) do
            -- Check if entity is one of our BBQ props
            local model = GetEntityModel(entity)
            for propName, propModel in pairs({
                bbq_stove = GetHashKey("prop_bbq_1"),
                table = GetHashKey("prop_table_04"),
                chair = GetHashKey("prop_chair_08"),
                soda_machine = GetHashKey("prop_food_cb_soda_02")
            }) do
                if model == propModel then
                    DeleteEntity(entity)
                    count = count + 1
                    break
                end
            end
        end
        
        lib.notify({
            title = 'Admin BBQ Cleanup',
            description = string.format('Removed %d props', count),
            type = 'success'
        })
    else
        lib.notify({
            title = 'Error',
            description = 'You don\'t have permission to use this command',
            type = 'error'
        })
    end
end, false)

-- Add command suggestions
CreateThread(function()
    TriggerEvent('chat:addSuggestion', '/clearbbq', 'Remove all BBQ props you have placed')
    TriggerEvent('chat:addSuggestion', '/clearallbbq', 'Remove all BBQ props on the map (Admin only)')
end)

AddEventHandler('onResourceStop', function(resourceName)
    if (GetCurrentResourceName() ~= resourceName) then return end
    
    -- Clean up all cooking items
    for i = #activeCookingItems, 1, -1 do
        DeleteEntity(activeCookingItems[i].prop)
    end
    
    -- Clear smoke effects
    if smoke then
        StopParticleFxLooped(smoke, 0)
        smoke = nil
    end
    
    -- Clear any ongoing animations
    local playerPed = PlayerPedId()
    ClearPedTasks(playerPed)
    
    -- Remove any attached props
    local spatula = GetClosestObjectOfType(GetEntityCoords(playerPed), 2.0, GetHashKey("prop_cs_spatula"), false, false, false)
    if DoesEntityExist(spatula) then
        DeleteEntity(spatula)
    end
end)