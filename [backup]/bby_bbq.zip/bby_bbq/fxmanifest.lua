fx_version 'cerulean'
game 'gta5'
lua54 'yes'

description 'Realistic BBQ Shop for FiveM with ox_target and ox_inventory'

shared_scripts {
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client.lua',
    'effects.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',  -- Optional, for database handling
    'server.lua',
    'events.lua'
}

dependencies {
    'ox_lib',
    'ox_target',
    'ox_inventory'
}
