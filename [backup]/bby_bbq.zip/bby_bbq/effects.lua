local smokeEffect = nil
local isCooking = false

-- Function to start smoke effect on the BBQ stove
RegisterNetEvent('bbqshop:startBBQSmoke')
AddEventHandler('bbqshop:startBBQSmoke', function(bbqProp)
    if isCooking then return end
    isCooking = true
    local coords = GetEntityCoords(bbqProp)
    
    -- Start smoke effect at BBQ location
    smokeEffect = StartParticleFxLoopedAtCoord("exp_grd_grenade_smoke", coords.x, coords.y, coords.z + 1.0, 0.0, 0.0, 0.0, 1.0, false, false, false)
    TriggerEvent('bbqshop:playSizzleSound') -- Play sizzle sound
end)

-- Function to stop smoke effect when cooking is done
RegisterNetEvent('bbqshop:stopBBQSmoke')
AddEventHandler('bbqshop:stopBBQSmoke', function()
    if smokeEffect then
        StopParticleFxLooped(smokeEffect, 0)
        smokeEffect = nil
        isCooking = false
    end
end)

-- Function to play sizzling sound while cooking
RegisterNetEvent('bbqshop:playSizzleSound')
AddEventHandler('bbqshop:playSizzleSound', function()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    PlaySoundFromCoord(-1, "BBQ_Sizzle", playerCoords, "DLC_HEIST_BIOLAB_PREP_HACKING_SOUNDS", 0, 0, 0)
end)

-- Nearby NPC Reaction to BBQ
RegisterNetEvent('bbqshop:nearbyNPCReaction')
AddEventHandler('bbqshop:nearbyNPCReaction', function()
    local playerPos = GetEntityCoords(PlayerPedId())
    local nearbyPeds = GetNearbyPeds(playerPos, 10.0)  -- Search radius for NPCs

    for _, npc in pairs(nearbyPeds) do
        TaskLookAtEntity(npc, PlayerPedId(), 3000, 0, 2)  -- NPCs look at player
        TaskStartScenarioInPlace(npc, "WORLD_HUMAN_CHEERING", 0, true)  -- NPC cheers
    end
end)

-- Utility function to get nearby NPCs
function GetNearbyPeds(coords, radius)
    local peds = {}
    for ped in EnumeratePeds() do
        if DoesEntityExist(ped) and not IsPedAPlayer(ped) then
            local pedCoords = GetEntityCoords(ped)
            local distance = #(coords - pedCoords)
            if distance <= radius then
                table.insert(peds, ped)
            end
        end
    end
    return peds
end
