-- Event handler to give the player a health boost after consuming BBQ items
RegisterNetEvent('bbqshop:consumeBBQItem')
AddEventHandler('bbqshop:consumeBBQItem', function(itemName)
    local xPlayer = ESX.GetPlayerFromId(source)
    xPlayer.removeInventoryItem(itemName, 1)
    TriggerClientEvent('esx_status:add', source, 'hunger', Config.Effects.HealthBoost)  -- Boost hunger or health
    TriggerClientEvent('ox_lib:notify', source, {description = 'You feel energized!', type = 'success'})
end)

-- Add this event if you want to manage cooldowns server-side
RegisterNetEvent('bbqshop:startCooldown')
AddEventHandler('bbqshop:startCooldown', function(stoveId)
    local cooldowns = Config.Cooldowns
    TriggerClientEvent('ox_lib:progress', source, {
        duration = cooldowns.BBQStove,
        label = 'Cooling down...',
        useWhileDead = false,
        canCancel = false
    })
end)
