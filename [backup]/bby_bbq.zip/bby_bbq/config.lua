Config = {
    -- General BBQ Shop Items (not meat)
    BBQItems = {
        {name = "bbq_stove", label = "BBQ Stove", price = 500},  -- Removed cooldown as it's handled in Config.Cooldowns
        {name = "spatula", label = "Spatula", price = 10},
        {name = "seasonings", label = "Seasonings", price = 5},
        {name = "table", label = "BBQ Table", price = 100},
        {name = "chair", label = "BBQ Chair", price = 50},
        {name = "soda_machine", label = "Soda Machine", price = 200}
    },

    -- Meat items for BBQ cooking
    BBQMeatItems = {
        {
            name = "pork_chops",
            label = "Pork Chops",
            price = 15,
            cookTime = 120000,    -- 2 minutes
            burnTime = 180000     -- 3 minutes
        },
        {
            name = "sausages",
            label = "Sausages",
            price = 10,
            cookTime = 120000,
            burnTime = 180000
        },
        {
            name = "steak",
            label = "Steak",
            price = 20,
            cookTime = 120000,
            burnTime = 180000
        },
        {
            name = "chicken_wings",
            label = "Chicken Wings",
            price = 12,
            cookTime = 120000,
            burnTime = 180000
        }
    },

    -- Soda machine configurations
    SodaFlavors = {
        {
            name = "cola",
            label = "Cola",
            ingredients = {"cup", "cola_syrup"}
        },
        {
            name = "lemon_lime",
            label = "Lemon Lime",
            ingredients = {"cup", "lemon_lime_syrup"}
        },
        {
            name = "orange",
            label = "Orange",
            ingredients = {"cup", "orange_syrup"}
        }
    },

    -- Time configurations (in milliseconds)
    Cooldowns = {
        BBQStove = 30000,        -- 30-second cooldown for the BBQ stove
        DefaultCookTime = 120000, -- Default cooking time (2 minutes)
        DefaultBurnTime = 180000  -- Default burn time (3 minutes)
    },

    -- Effect configurations
    Effects = {
        HealthBoost = 200000     -- Health boost duration for consumable items
    },

    -- Item types for easy reference
    ItemTypes = {
        RAW = "_raw",
        COOKED = "_cooked",
        BURNT = "_burnt"
    }
}

-- Add some helper functions
function Config.IsBBQItem(itemName)
    for _, item in pairs(Config.BBQItems) do
        if item.name == itemName then
            return true
        end
    end
    return false
end

function Config.IsMeatItem(itemName)
    for _, item in pairs(Config.BBQMeatItems) do
        if item.name == itemName then
            return true
        end
    end
    return false
end

function Config.GetMeatItem(itemName)
    for _, item in pairs(Config.BBQMeatItems) do
        if item.name == itemName then
            return item
        end
    end
    return nil
end

function Config.GetSodaFlavor(flavorName)
    for _, flavor in pairs(Config.SodaFlavors) do
        if flavor.name == flavorName then
            return flavor
        end
    end
    return nil
end